use std::collections::HashMap;

/// A flat list of points. A point is found every 2 elements, a complete line every 4,
/// e.g. `[x11,y11,x12,y12...xn1,yn1]`
fn parse_points(input: &str) -> Vec<i32> {
    let mut coordinates: Vec<i32> = vec![];
    let lines: Vec<String> = input
        .lines()
        .map(|x| x.trim().replace(" -> ", ","))
        .collect();

    for line in lines {
        coordinates.append(&mut line.split(",").map(|y| y.parse::<i32>().unwrap()).collect());
    }

    coordinates
}

fn retain_horizontal_or_vertical(coordinates: Vec<i32>) -> Vec<i32> {
    let mut retained_coordinates = vec![];

    // a point is found every 4 elements
    for p in coordinates.chunks_exact(4) {
        if p[0] == p[2] || p[1] == p[3] {
            retained_coordinates.append(&mut p.to_vec());
        }
    }

    retained_coordinates
}

pub fn part_1(input: &str) -> i32 {
    let points = retain_horizontal_or_vertical(parse_points(input));
    let mut lines= vec![];
    let coordinates: Vec<(&str, &str)> = input
        .lines()
        .map(|x| x.trim().split_once(" -> ").unwrap())
        .collect::<Vec<(&str, &str)>>()
        .map(|x: (&str, &str)| {
            let mut tuple = x.0.split_once(",").unwrap();
            lines.append(&mut (tuple.0.parse::<i32>().unwrap(), tuple.1.parse::<i32>().unwrap()));
            tuple = x.1.split_once(",").unwrap();
            lines.append(&mut (tuple.0.parse::<i32>().unwrap(), tuple.1.parse::<i32>().unwrap()))
        })
        .collect();

    // for line in coordinates {
    //     lines.append(line.split_once(',').unwrap());
    // }

    println!("{:?}", lines);

    for l in points.chunks_exact(4) {
        // starting point
        lines.push((l[0], l[1]));

        // 2-point long line
        if (l[0] - l[2]).abs() == 1 || (l[1] - l[3]).abs() == 1 {
            lines.push((l[2], l[3]));
            continue;
        }

        if l[1] == l[3] {
            // increment horizontally
            for i in 0..(l[0] - l[2]).abs() {
                if l[0] < l[2] {
                    // grows left
                    lines.push((l[0] + i + 1, l[3]));
                } else {
                    // grows right
                    lines.push((l[0] - i - 1, l[3]));
                }
            }
        } else {
            // increment vertically
            for i in 0..(l[1] - l[3]).abs() {
                if l[1] < l[3] {
                    // grows up
                    lines.push((l[2], l[1] + i + 1));
                } else {
                    // grows down
                    lines.push((l[2], l[3] + i + 1));
                }
            }
        }
    }

    // ((x,y), no of matches)
    let mut matches: HashMap<(i32, i32), i32> = HashMap::new();
    let mut overlaps = 0;

    for p in lines {
        *matches.entry(p).or_insert(0) += 1;
    }

    for m in matches.iter() {
        if *m.1 >= 2 {
            overlaps += 1
        }
    }

    overlaps
}

#[cfg(test)]
mod day_05_tests {
    use super::*;
    use std::fs;

    #[test]
    fn part_1_test() {
        let result = part_1(
            fs::read_to_string("./data/day_05_test.txt")
                .unwrap()
                .as_str(),
        );
        assert_eq!(5, result);
    }

    mod parse_coordinates_test {
        use super::super::*;

        #[test]
        fn parse_points_to_vec() {
            let input = "0,9 -> 5,9
            8,0 -> 0,8
            9,4 -> 3,4
            2,2 -> 2,1";
            let expected = vec![0, 9, 5, 9, 8, 0, 0, 8, 9, 4, 3, 4, 2, 2, 2, 1];
            assert_eq!(expected, parse_points(input))
        }
    }

    mod retain_horizontal_or_vertical_test {
        use super::super::*;

        #[test]
        fn retain_horizontal_or_vertical_vec() {
            let input = vec![0, 9, 5, 9, 8, 0, 0, 8, 9, 4, 3, 4, 2, 2, 2, 1];
            let expected = vec![0, 9, 5, 9, 9, 4, 3, 4, 2, 2, 2, 1];
            assert_eq!(expected, retain_horizontal_or_vertical(input))
        }
    }
}
